#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import webapp2
import os
import urllib
import jinja2

JINJA_ENVIRONMENT = jinja2.Environment(
	loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
	extensions=['jinja2.ext.autoescape'],
	autoescape=True)
	
	
	
num = 0	
	
	def post(self):
		template = JINJA_ENVIRONMENT.get_template('index.html')
			aTriples = []
		num = int(self.request.get('num'))
		print('num: ' + str(num))
		for i in range(1, num):
			for j in range(1, num):
				for k in range(1, num):
					i2 = i*i
					j2 = j*j
					k2 = k*k
						singleTriple = []
					singleTriple.append(i)
						singleTriple.append(j)
						singleTriple.append(k)
						aTriples.append(singleTriple)
		template_values = {
			'aTriples' : aTriples,
		}
		print(aTriples)
		
		self.response.out.write(template.render())
	
class MainHandler(webapp2.RequestHandler):
	def get(self):
	template_values={
		'title' :'Test'
	
	}
		template=JINJA_ENVIRONMENT.get_template('file:///C:/Users/jerem/Documents/CompSci%20482/Assignment_8/index.html')
		self.response.out.write(template.render(template_values))
		
		
		

class Result(webapp2.RequestHandler):
	def post(self):
		template = JINJA_ENVIRONMENT.get_template('file:///C:/Users/jerem/Documents/CompSci%20482/Assignment_8/result.html.html')
		num = int(self.request.get('num'))
		template_values = {
			'num': num,
		}
		self.response.write(template.render(template_values))

app = webapp2.WSGIApplication([
	('/', MainHandler),
	("/result", Result)
], debug=True)
