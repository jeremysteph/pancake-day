var pipeHeight = 150;
var pipeWidth = 52;
var score = 0;
var highscore = 0;
var replayclickable = false;
var gameCanvas; 
var ctx;
var birdImg =new Image();
//new variable pipe
var timer;
var player;
var vy;
var y =0;
var x=0;

//loops for pipes & game
var gameLoop;
var pipeLoop;
//var backgroundImg = gameCanvas.toDataURL("img/background.png");

var started = false; 
            var startJump = false; // Has the jump started?

            var jumpAmount = 120; // How high is the jump?
            var jumpTime = 266;

            var dead = false; // is the bird dead?

function preLoader(){
	
	
		birdImg.src="img/abird.png";
}


document.addEventListener("DOMContentLoaded", function() {
	preLoader();
	gameCanvas = document.getElementById("gameCanvas");
	gameCanvas.style.backgroundImage = "url('img/cloud1.png')";
	ctx = gameCanvas.getContext("2d");

	welcomeScreen();
	
	});

function welcomeScreen(){
	ctx.font = "30px Comic Sans MS";
ctx.fillStyle = "Green";
ctx.textAlign = "center";
ctx.fillText("Click to start",gameCanvas.width/2, gameCanvas.height/2);

gameCanvas.addEventListener("click", initGame);
}

function initGame(){
	
//Sets the initial value of the bird's change in velocity
vy=0;

gameCanvas.removeEventListener("click",initGame);

ctx.clearRect(100,100,gameCanvas.width/2,gameCanvas.height/2);


ctx.fillText("Score: " + score,400,50);


    
ctx.drawImage(birdImg,gameCanvas.width/2,gameCanvas.height/2.5,60,60);


//create initial pipes
pipe = new Pipe(Math.floor((Math.random()*10)+650),y, pipeWidth,Math.floor((Math.random() * 25) + 150));
pipe2 = new Pipe(Math.floor((Math.random()*50)+670),300, pipeWidth,Math.floor((Math.random() * 15) + 165));
pipe3 = new Pipe(Math.floor((Math.random()*5)+770),300, pipeWidth,Math.floor((Math.random() * 15) + 175));

player = new Player(birdImg,gameCanvas.width/2,gameCanvas.height/2,60,60);
   timer = setInterval(Game,20);
}

function Pipe(x, y, pipeWidth, pipeHeight){
	this.x = x;
	this.y = y;
	this.pipeWidth = pipeWidth;
	this.pipeHeight = pipeHeight;
	
	ctx.fillStyle="#009900";
	ctx.fillRect(x,y, pipeWidth,pipeHeight);
	ctx.stroke();
	
}

function pipeMovement(){
	
	if(pipe.x>0||pipe2.x>0||pipe3>0){
		pipe.x=pipe.x-3;
		pipe2.x=pipe2.x-3;
		pipe3.x=pipe3.x-3;
				}

if(pipe.x<0||pipe2.x<0||pipe3<0){
	pipe = new Pipe(Math.floor((Math.random()*10)+650),0, pipeWidth,Math.floor((Math.random() * 110) + 145));
	pipe2 = new Pipe(Math.floor((Math.random()*50)+680),300, pipeWidth,Math.floor((Math.random() * 100) + 150));
	pipe3 = new Pipe(Math.floor((Math.random()*5)+770),Math.floor((Math.random()*2)+0)*300, pipeWidth,Math.floor((Math.random() * 80) + 200));

	}
	

ctx.fillRect(pipe.x,  pipe.y, pipeWidth, pipe.pipeHeight);
ctx.fillRect(pipe2.x,pipe2.y, pipeWidth,pipe2.pipeHeight);
ctx.fillRect(pipe3.x,pipe3.y, pipeWidth,pipe3.pipeHeight);

}

function playerMovement(){
// Velocity y
	
vy=vy+2;
	//ctx.save();
//	  ctx.translate(100,100); // to get it in the origin

gameCanvas.addEventListener('keydown', this.spaceBarKey,false);
gameCanvas.addEventListener('click', this.clickHandler,false);

	ctx.drawImage(player.img,gameCanvas.width/2,(gameCanvas.height/2)+vy,55,55);
//ctx.restore();


}

//Function to handle animation of bird when player taps the spaceBarKey on gameCanvas
function spaceBarKey(e){
	
    if(e.keyCode == 32){

vy=vy-35;
	ctx.drawImage(player.img,gameCanvas.width/2,(gameCanvas.height/2)+vy,55,55);

    }
	
}

//Function to handle animation of bird when player clicks on gameCanvas
function clickHandler(e){
	
vy=vy-35;
ctx.drawImage(player.img,gameCanvas.width/2,(gameCanvas.height/2)+vy,55,55);
   
}

function Player(img,x,vy, width,height){
	
	this.x = x;
	this.vy = vy;
	this.width = width;
	this.height = height;
	this.img = img;

}
function playerDies(){
console.log("Canvas height: "+ gameCanvas.height);
console.log("Bird height: " + vy);
	if(vy>gameCanvas.height){
	ctx.font = "50px Comic Sans MS";
	ctx.fillStyle = "Red";
	ctx.fillText("Game Over!",gameCanvas.width/2,gameCanvas.height/2);
	ctx.font = "20px Comic Sans MS";
	ctx.fillText("Click to play again!",gameCanvas.width/2,gameCanvas.height/1.5);
	gameCanvas.addEventListener("click", initGame);

		clearInterval(timer);

	}
	
	
}

function Game(){

ctx.clearRect(0,0,gameCanvas.width,gameCanvas.height);
ctx.fillText("Score: " + score,400,50);
pipeMovement();
playerMovement();
playerDies();
}
