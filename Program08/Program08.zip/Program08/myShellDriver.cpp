#include "myShell.h"

int main(int argc, char *argv[])
{
    myShell shell;
    shell.runShell();
    return 0;
}