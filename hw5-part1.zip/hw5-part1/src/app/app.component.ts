import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title:string            = 'Homework Assignment 5';
  selectedApp:string   = "MapQuest Part 1";


  ngOnInit() {
 
    }
  



}
