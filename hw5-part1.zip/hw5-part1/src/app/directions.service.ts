import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DirectionsService {


  key = "GO11hsWcA9Qmex13QdgZXAlD3Msli9xb";
  constructor(private http: HttpClient) { }


  getDirections(from: string, to:string): Observable<any> {
    let url: string = "http://open.mapquestapi.com/directions/v2/route?key=" + this.key + "&from=" +
      encodeURI(from) + "&to=" + encodeURI(to) + "format=json";

    return this.http
      .jsonp(url, 'jsoncallback')

  }
}
