import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { callbackify } from 'util';

@Injectable({
  providedIn: 'root'
})


export class DirectionsService {

  

  key = "GO11hsWcA9Qmex13QdgZXAlD3Msli9xb";
  constructor(private http: HttpClient) { }


  getDirections(from: string,to:string): Observable<any> {

    
    let url: string = "http://open.mapquestapi.com/directions/v2/route?key=" + this.key + "&from=" +
    encodeURIComponent(from) + "&to=" + encodeURIComponent(to);
      console.log(url);

    return this.http.jsonp(url, 'callback')

  }
}
