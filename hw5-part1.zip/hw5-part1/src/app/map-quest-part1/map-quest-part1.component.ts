import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, Subject,from,of} from 'rxjs';
import {mergeAll} from 'rxjs/operators';
import { DirectionsService } from '../services/directions.service';
import { debounceTime, distinctUntilChanged, switchMap, subscribeOn} from 
						'rxjs/operators';

@Component({
  selector: 'app-map-quest-part1',
  templateUrl: './map-quest-part1.component.html',
  styleUrls: ['./map-quest-part1.component.css']
})

export class MapQuestPart1Component implements OnInit {
  
  from: string = "Boston, MA";
  to: string = "Cambridge, MA";
  dataItems: any;
  time:number=0;
  distance:number=0;
    // a subject to publish start and end locations
    private destination: Subject<string>;

  constructor(private directionService: DirectionsService) { 

}
  // Push a search term into the observable stream.
	startDest(newDes:string): void {
	  this.destination.next(newDes);
  }
	endDest(newDes:string): void {
	  this.destination.next(newDes);
  }
  
  ngOnInit() {
  this.getDirections(this.from,this.to);
    this.destination = new Subject<string>();
   
  this.destination.pipe(
  			// wait 1000ms after each keystroke before considering the term
  			debounceTime(1000),
  
      	switchMap((startDest,endDest) => {
    
          return this.directionService.getDirections(this.from, this.to)
          
      	})
  		)
  	  .subscribe((result:any)=> 
			{
        console.log(result);
        this.dataItems = result.route.legs[0].maneuvers;

        this.time=result.route.formattedTime;
        this.distance =result.route.distance;
			});
  }

  getDirections(from:string, to:string){
    return this.directionService.getDirections(this.from, this.to).subscribe((result:any)=> 
    {
      console.log(result);
      this.dataItems = result.route.legs[0].maneuvers;
      this.time=result.route.formattedTime;
      this.distance =result.route.distance;
    });

  }


}


