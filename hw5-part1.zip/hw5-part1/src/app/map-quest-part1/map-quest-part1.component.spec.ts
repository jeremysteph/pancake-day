import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapQuestPart1Component } from './map-quest-part1.component';

describe('MapQuestPart1Component', () => {
  let component: MapQuestPart1Component;
  let fixture: ComponentFixture<MapQuestPart1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MapQuestPart1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapQuestPart1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
