var gameCanvas; 
var ctx;
var player;
var timer;
var contentElement;
var dayOfWeek =["Monday", "Tuesday", "Wednesday","Thursday", "Friday"];
var introParagraph;
var introHeader;
var x;

$(document).ready(function(){
gameCanvas = document.getElementById("gameCanvas");
ctx = gameCanvas.getContext("2d");
	contentElement = document.getElementById("content");
	welcomeScreen();
	
});




function welcomeScreen(){

	ctx.font = "40px Comic Sans MS";
ctx.fillStyle = "White";
ctx.textAlign = "center";

	 ctx.fillText("Fired Another Day!", gameCanvas.width/2,gameCanvas.height/2);
timer();


}

function timer(){
	setTimeout(clickToStart, 3000);


	
}
function clickToStart(){
ctx.clearRect(0,0,gameCanvas.width,gameCanvas.height);
		 ctx.fillText("Click to start",gameCanvas.width/2, gameCanvas.height/2);
	 gameCanvas.addEventListener("click", Game);


}

function prologueText(){

x = Math.floor((Math.random() * 4) + 0);
introHeader = document.createElement("h1");
introHeader.id="introHeader";
 introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 5:30 a.m. ";
 contentElement.appendChild(introHeader);
 
introParagraph = document.createElement("p");
introParagraph.id="introParagraph";
introParagraph.innerHTML= "<br/><i>....brrrrrrringg....brrrrinnnggg...BRINNGGGGG<br/>***Hits Snooze button***<br/>"+
"....hours laters....</br>"+
" ***Yawns...(sighs)...looks at the time...!!!!!!! <br/>";
contentElement.appendChild(introParagraph);
	
	setTimeout(stage1,3000);
	
	
}
function stage1(){
	contentElement.removeChild(introParagraph);
	contentElement.removeChild(introHeader);	
	introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 7:45 a.m. ";
	contentElement.appendChild(introHeader);
	
	var stage_1 = document.createElement("p");
	stage_1.id= "stage_1";
	stage_1.innerHTML= "<p> !!!!!!!....IT'S 7:45 a.m.!!!...you have to be at work by 8:30 a.m.!!!!</i><br/><br/>" +
"Given the time you realize you can't do your entire morning routine. So you'll have to decide what's most important. You haven't brushed,"+
"showered, or picked out your outfit. Your commute to work usually is a 40 minute drive one way and that's depending on traffic and the path you take. </br>"+
"<br/> You need to get ready for work. Do you: </p></br></br>"+
"<ul><li onClick='stage2(stage_1)'>A.) Brush for 5 minutes, skip taking a shower, and fix a quick breakfast.</li>" +
		"<li onClick='stage5(stage_1)'> B.) Brush for 5 minutes and shower for 5 minutes.</li>" +
		"<li onClick='stage6(stage_1)'> C.) Brush for 5 minutes, use mouth wash (takes 1 minute) and shower for 5 minutes</li>" +
		"<li onClick = 'stage7(stage_1)'> D.) Don't brush, shower, or use mouth wash. Use mints, spray cologne, and skip breakfest</li></ul>";
		contentElement.appendChild(stage_1);

		}
		
function stage2(stage_1){

	contentElement.removeChild(stage_1);
	contentElement.removeChild(introHeader);

	var stage_2 = document.createElement("p");
	stage_2.id= "stage_2";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:00 a.m. ";
	contentElement.appendChild(introHeader);
	
	stage_2.innerHTML= "<p> You've brushed your teeth for 5 minutes. You skipped taking a shower and you decide to" 
	+	"grab a poptart for breakfast. Not the best breakfast but nevertheless should help prevent you from being too late while putting food in your stomach."+
	"You head out the door, start your car, and make your way to down the driveway. You are now down the block. " +
	"However you just remember you left your work badge. Do you: "
	+"<ul><li onClick='stage3(stage_2)'>A.) Keep going because you will already be 10 minutes late.</li>" +
		"<li> B.) Turn around and go back to get it?</li>";
		contentElement.appendChild(stage_2);

		}

function stage3(stage_2){

	contentElement.removeChild(stage_2);
	contentElement.removeChild(introHeader);

	var stage_3 = document.createElement("p");
	stage_3.id= "stage_3";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:10 a.m. ";
	contentElement.appendChild(introHeader);
	
	stage_3.innerHTML= "<p> As you are driving you notice the freeway appears to be backed up. You can either proceed with entering the freeway or take an alternative path"
	+ " Do you: "
	+"<ul><li onClick='stage4(stage_3)'>A.) Take your chances and hop on the freeway anyway since you are already late?</li>" +
		"<li onClick=stage9(stage_3)> B.) Take the street path which will make you 30 minutes late for sure?</li>";
		contentElement.appendChild(stage_3);

		}
		
function stage4(stage_3){

	contentElement.removeChild(stage_3);
	contentElement.removeChild(introHeader);

	var stage_4 = document.createElement("p");
	stage_4.id= "stage_4";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:20 a.m. ";
	contentElement.appendChild(introHeader);
	
	stage_4.innerHTML= "<p> You are now on the freeway and there appears to be an accident. Traffic is backed up 15 minutes which means the earliest" +
	"you'd make it to work is 8:55 a.m. which is 25 minutes late! You start to feel lightheaded. You realize it may be best to call your boss and let him" +
	"know you will be late. You are afraid he may fire you over the phone. Do you: "
	+"<ul><li onClick='stage8(stage_4)'>A.) Call in anyway since it's 8:20 a.m. He will appreciate you calling him ahead of time.</li>" +
		"<li onClick='ending5(stage4)'> B.) Screw it..call in sick...You had that one resturant featured on dirty dining. Besides he won't know you are lying.</li>"+
		"<li = onClick ='ending3(stage_4)'>C.) Don't call your boss. You know he doesn't like to answer his phone anyway. Just walk in late and act like nothing happened.</li>";
		contentElement.appendChild(stage_4);

		}

		function stage5(stage_1){

	contentElement.removeChild(stage_1);
	contentElement.removeChild(introHeader);

	var stage_5 = document.createElement("p");
	stage_5.id= "stage_5";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:10 a.m. ";
	contentElement.appendChild(introHeader);
	
	stage_5.innerHTML= "<p> You've brushed and showered for 5 minutes. You are struggling to get ready. Your clothes get wet" +
	"from not properly drying off. But what do you care. You need to get to work and still smell fresh"+
	" You start your car up and realize you left your work badge behind. You decide you aren't getting it because you are already running late."+
	"without thinking you turn onto the freeway ramp. Traffic is backed up 15 minutes which means the earliest" +
	"you'd make it to work is 8:55 a.m. which is 25 minutes late! You start to feel lightheaded. You realize it may be best to call your boss and let him" +
	"know you will be late. You are afraid he may fire you over the phone. Do you: "
	+"<ul><li onClick='stage8(stage_5)'>A.) Call in anyway since it's 8:20 a.m. He will appreciate you calling him ahead of time.</li>" +
		"<li onClick='ending5(stage5)'> B.) Screw it..call in sick...You had that one resturant featured on dirty dining. Besides he won't know you are lying.</li>"+
		"<li = onClick ='ending3(stage_5)'>C.) Don't call your boss. You know he doesn't like to answer his phone anyway. Just walk in late and act like nothing happened.</li>";
		contentElement.appendChild(stage_5);

		}

function stage6(stage_1){

	contentElement.removeChild(stage_1);
	contentElement.removeChild(introHeader);

	var stage_6 = document.createElement("p");
	stage_6.id= "stage_6";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:11 a.m. ";
	contentElement.appendChild(introHeader);
	
	stage_6.innerHTML= "<p> You've brushed, used mouth wash, and showered for 11 minutes. You are struggling to get ready. Your clothes are wrinkled." +
	"because you threw whatever shirt you saw first on. Your breath is super fresh and you smell fresh"+
	" You start your car up and realize you left your work badge behind. You decide you aren't getting it because you are already running late."+
	"without thinking you keep straight passing the freeway. You are now stuck with taking the alternative path. Traffic is light but you will still be 16 minutes late"+
	"which means the earliest you'd make it to work is 8:56 a.m. which is 26 minutes late!" +
	"You realizee you can speed to work or drive the speed limit." +"You know you will be late but you can still let your boss know. Do you: "
	+"<ul><li onClick='ending4(stage_6)'>A.) Speed, speed, SPEED! You already have high insurance rates because you drive safely.</li>" +
		"<li onClick='ending3(stage_6)'> B.) Do the speed limit but call your boss and let him know you will be late.</li>";
		contentElement.appendChild(stage_6);

		}		
		
function stage7(stage_1){

	contentElement.removeChild(stage_1);
	contentElement.removeChild(introHeader);

	var stage_7 = document.createElement("p");
	stage_7.id= "stage_3";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:10 a.m. ";
	contentElement.appendChild(introHeader);
	
	stage_7.innerHTML= "<p> As you are driving you notice the freeway appears to be backed up. You can either proceed with entering the freeway or take an alternative path"
	+ "Do you: "
	+"<ul><li onClick='stage4(stage_3)'>A.) Take your chances and hop on the freeway anyway since you are already late?</li>" +
		"<li> B.) Take the street path which will make you 30 minutes late for sure?</li>";
		contentElement.appendChild(stage_7);

		}

function stage8(stage_4){

	contentElement.removeChild(stage_4);
	contentElement.removeChild(introHeader);

	var stage_8 = document.createElement("p");
	stage_8.id= "stage_8";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:25 a.m. ";
	contentElement.appendChild(introHeader);
	
	stage_8.innerHTML= "<p> Your boss doesn't pick up as expected. You can either leave a voice mail or hang up: "
	+"<ul><li onClick='ending2(stage_8)'>A.) Leave a voicemail. Telling him you'll be late.</li>" +
		"<li onClick='ending5(stage8)'> B.) You've changed your mind and decided it'd be best to tell him you are sick from food poisoning.</li>"+
		"<li = onClick ='ending3(stage_8)'>C.) Hang up and just show up to work extremely late.</li>";
		contentElement.appendChild(stage_8);

		}	
function stage9(stage_4){

	contentElement.removeChild(stage_4);
	contentElement.removeChild(introHeader);

	var stage_9 = document.createElement("p");
	stage_9.id= "stage_9";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:35 a.m. ";
	contentElement.appendChild(introHeader);
	
	stage_9.innerHTML= "<p> You are running extremely late. You decide to call your boss to let him know. Your boss doesn't pick up as expected. You can either leave a voice mail or hang up: "
	+"<ul><li onClick='stage10(stage_8)'>A.) Leave a voicemail. Telling him you'll be late.</li>" +
		"<li onClick='stage11(stage8)'> B.) You've changed your mind and decided it'd be best to tell him you are sick from food poisoning.</li>"+
		"<li = onClick ='ending3(stage_8)'>C.) Hang up and just show up to work extremely late.</li>";
		contentElement.appendChild(stage_9);

		}	
		
	function stage10(stage_4){

	contentElement.removeChild(stage_4);
	contentElement.removeChild(introHeader);

	var stage_10 = document.createElement("p");
	stage_10.id= "stage_10";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:25 a.m. ";
	contentElement.appendChild(introHeader);
	
	stage_10.innerHTML= "<p> Your boss doesn't pick up as expected. You can either leave a voice mail or hang up: "
	+"<ul><li onClick='ending2(stage_10)'>A.) Leave a voicemail. Telling him you'll be late.</li>" +
		"<li onClick='ending5(stage10)'> B.) You've changed your mind and decided it'd be best to tell him you are sick from food poisoning.</li>"+
		"<li = onClick ='ending3(stage_10)'>C.) Hang up and just show up to work extremely late.</li>";
		contentElement.appendChild(stage_10);

		}	function stage11(stage_4){

	contentElement.removeChild(stage_4);
	contentElement.removeChild(introHeader);

	var stage_11 = document.createElement("p");
	stage_11.id= "stage_11";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:25 a.m. ";
	contentElement.appendChild(introHeader);
	
	stage_11.innerHTML= "<p> Your boss doesn't pick up as expected. You can either leave a voice mail or hang up: "
	+"<ul><li onClick='stage10(stage_8)'>A.) Leave a voicemail. Telling him you'll be late.</li>" +
		"<li onClick='stage11(stage8)'> B.) You've changed your mind and decided it'd be best to tell him you are sick from food poisoning.</li>"+
		"<li = onClick ='ending3(stage_8)'>C.) Hang up and just show up to work extremely late.</li>";
		contentElement.appendChild(stage_11);

		}	

		
function ending1(stage){

	contentElement.removeChild(stage);
	contentElement.removeChild(introHeader);

	var ending_1 = document.createElement("p");
	ending_1.id= "ending3";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:40 a.m. ";
	contentElement.appendChild(introHeader);
	
	ending_1.innerHTML= "<p>You finally make it into the office. You notice your boss isn't in his office. Whew a sigh of relief. You make your way to your cubical." +
	"You get to your cubical. You are only 10 minutes late. Your boss shows up and begins holding a morning coversation with you. " +
	"You notice he's making weird faces as he speaks with you. Those mints must not have done as good of a job as you had hoped. He seems disgusted." +
	"All of sudden you hear the voice of your boss \"Uhmm, we need to talk. Your hygeine is part of our company's pride. You aren't being professional "+
	"smelling the way you are. I'm going to write you uop and send you home this time. But next time you come to work smelling the way you do...YOU'RE FIRED!\"";
		contentElement.appendChild(ending_1);

		}	
		
function ending2(stage){

	contentElement.removeChild(stage);
	contentElement.removeChild(introHeader);

	var ending_2 = document.createElement("p");
	ending_2.id= "ending3";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:55 a.m. ";
	contentElement.appendChild(introHeader);
	
	ending_2.innerHTML= "<p>You finally make it into the office. You notice your boss isn't in his office he's in a meeting. You make your way to your cubical." +
	"You get to your cubical and login into your PC. You proceed with your daily routine. 2 hours later you get an email from your boss requesting to see you." +
	"You walk into your boss's office. You notice he looks pissed. You stand there frozen not saying a word. \"Well I thought you weren't showing up for a second. Glad you called"+
 ",otherwise I'd have no choice but to fire you. Just don't let this happen again!!\"";
		contentElement.appendChild(ending_2);

		}			
function ending3(stage){

	contentElement.removeChild(stage);
	contentElement.removeChild(introHeader);

	var ending_3 = document.createElement("p");
	ending_3.id= "ending3";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 8:55 a.m. ";
	contentElement.appendChild(introHeader);
	
	ending_3.innerHTML= "<p>You finally make it into the office. You notice your boss isn't in his office. Whew a sigh of relief. You make your way to your cubical." +
	"You get to your cubical and notice your stuff is packed up in two boxes. Your eyes swell up. You stand there in amazement knowing what's coming next." +
	"All of sudden you hear the voice of your boss \"Well hey there...I'm glad I caught you before you got too comfortable. You no longer work here. YOU'RE FIRED!!!\"";
		contentElement.appendChild(ending_3);

		}	
		
function ending4(stage){

	contentElement.removeChild(stage);
	contentElement.removeChild(introHeader);

	var ending_4 = document.createElement("p");
	ending_4.id= "ending4";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 9:05 a.m. ";
	contentElement.appendChild(introHeader);
	
	ending_4.innerHTML= "<p>You finally make it into the office. You notice your boss isn't in his office. Whew a sigh of relief. You make your way to your cubical." +
	"You get to your cubical and notice your stuff is packed up in two boxes. Your eyes swell up. You stand there in amazement knowing what's coming next." +
	"All of sudden you hear the voice of your boss \"YOU'RE FIRED!!!\"";
		contentElement.appendChild(ending_4);

		}			
		
		function ending5(stage){

	contentElement.removeChild(stage);
	contentElement.removeChild(introHeader);

	var ending_5 = document.createElement("p");
	ending_5.id= "ending5";
		introHeader.innerHTML= dayOfWeek[x] +" March 7th, 2016 9:05 a.m. ";
	contentElement.appendChild(introHeader);
	
	ending_5.innerHTML= "<p>You finally make it back home after calling in sick. Tough luck. It seems suspecious but you hope you don't get a call from your boss."+
	"You go the whole day without hearing from your boss. You feel as if the sucker fell for it, though you kinda feel guilty for lying. You decide to go to the bar that evening" +
	"The next morning you get up extremely early and get to work on time. Later in the day your boss stops by your desk and ask how you feel. You reply " +
	"\"Just peachy!\" "+ "You boss stares at you for 2 minutes. You are now sweating bullets.... Your boss tells you that he saw you entering the bar you went to the night before." +
	"Freaking out you say it wasn't you. But your boss mentioned he walked into the bar not long after you did and saw you for sure. You think for a second and " +
	"realize that you weren't hallucinating when you saw your boss sitting in the corner of the bar staring at you intensely after many rounds of drinks. "+
	"Your eyes swell up. You sit there in amazement knowing what's coming next." +
	"All of sudden you hear the voice of your boss \"YOU'RE FIRED!!!\"";
		contentElement.appendChild(ending_5);

		}	
		function Game(){
$('canvas').remove();
prologueText();

}
