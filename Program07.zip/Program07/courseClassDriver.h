#ifndef COURSEDRIVER_H
#define COURSEDRIVER_H
#include "daysOfWeek.h"
#include "Course.h"
#include "dtime.h"
#include "timeInterval.h"
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
using namespace std;
	void add(vector<Course>& s, const string* input, size_t size);
	void clear(vector<Course>& sch);
	void exportSchedule(const vector<Course>& s, string fileName);
	void importSchedule(vector<Course>& s, string fileName);
	void remove(vector<Course>& s, string courseCode, string sections);
	void validate(const vector<Course>& s);
	void parseInput(string* parse, string input, size_t size);
	int wordCount(string input);
#endif