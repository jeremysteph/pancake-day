var likes=0;


var script = document.createElement('script');
script.src = 'https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

function ser_Sending(){
	$.ajax({
		type:"GET",
		url:"/increment"
		});
}
  


function ser_Receiving(){
	$.get("/counter", function(x){
	$("#page_Likes").html(x);
	});
}
$(function likeButtonClick()
{
	
$("page_Likes").bind(eventType = 'click', handler = sending);
setInterval(receiving,100);
	
});
function sending(){
	$.ajax({
		type:"GET",
		url:"/increment"
		});
}