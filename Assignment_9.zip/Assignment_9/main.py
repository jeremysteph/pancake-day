import webapp2
import jinja2
import os
import urllib
from google.appengine.ext import ndb


class Likes(ndb.Model):
	value = ndb.IntegerProperty()


JINJA_ENVIRONMENT = jinja2.Environment(
loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
extensions=['jinja2.ext.autoescape'],
autoescape=True)

class MainHandler(webapp2.RequestHandler):
	def get(self):
		x={}
		template = JINJA_ENVIRONMENT.get_template('web_templates/index.html')
		self.response.write(template.render(x))

class Increment(webapp2.RequestHandler):
	def get(self):
		myCounter = ndb.Key(Likes,'unique').get()
		if not myCounter:
			myCounter = Likes(id='unique',value=0)
		myCounter.value = myCounter.value + 1
		myCounter.put()


class Counter(webapp2.RequestHandler):
	def get(self):
		myCounter = ndb.Key(Likes,'unique').get()
		if not myCounter:
			myCounter = Likes(key_name='unique',value=0)
		self.response.write(myCounter.value)

app = webapp2.WSGIApplication([
('/', MainHandler),
('/increment',Increment),
('/counter',Counter)
], debug=True)
