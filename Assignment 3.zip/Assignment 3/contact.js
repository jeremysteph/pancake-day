

//initial email field count
var i=1;

//variable to hold emails
var emails = [];

//variable to hold id of main form
var formElements;

//on load event that sets the heading
window.onload = document.write('<div id="header"><h1> Spamulator 2000</h1>');

//On load event that sets the variable formElements to the same value as the ID of the div tag in the HTML code
window.addEventListener("DOMContentLoaded", function(){

formElements = document.getElementById('formElements');
getSubmitButton();



//creates 3 email input fields initially
for(var j=0;j<3;j++){
makeNew(formElements);

}

});


//validates form
function validateForm(evt){
	getEmailInputs();
var dupValue;
	var emailArray = Object.create(null);
    for (var i = 0; i < emails.length; ++i) {
        var email = emails[i].value;
        if (email in emailArray) {
		
	for(var j=0;j<=i;j++){
		if(emails[j].value==emails[(i+1)%2].value){
		emails[j].style.color='#FF0000';
		}
	}
alert("Duplicates found! Please fix and resubmit");
		evt.preventDefault();
			return true;
        }
		
       emailArray[email] = true;
    }
	return false;


}





//Function that on click of [+] sign creates new email input element
window.onload = function(){	

	var plusSign = document.getElementById('new');

	plusSign.onclick = function (){
	 makeNew(formElements);


	 }
	 

}

//onsubmit function
window.onsubmit = function(evt){

	formElements.addEventListener("submit", validateForm(evt),false);
	}
	 

//parses form to find the submit button
 function getSubmitButton(){
	
	var submitButton = document.getElementsByTagName("INPUT");
	
	for(var k=0; k<submitButton.length;k++){
	
	if(submitButton[k].getAttribute("type")=="submit")
	{
			console.log(submitButton[k]);

		return submitButton[k];
		
	}
 }

 }



function getEmailInputs(){
var email = document.getElementsByTagName("INPUT");

	for(var g=0; g<email.length; g++){

	if(email[g].getAttribute("type")=="email")
	{
console.log(email[g]);	
	emails.push(email[g]);
	
	}
	
	}
	return emails;
}

//Function responsible for making a new email input on the form
function makeNew(mainDiv){
var input = document.createElement("input");
var div = document.createElement("div");
var link_ =document.createElement("a");
var link_text = document.createTextNode("[-]");

link_.href ="javascript:void(0)";
link_.onclick= function(){
	removeElement(div);
};

link_.appendChild(link_text);
link_.name="minusSign";
link_.id="minusSign";

input.appendChild(link_);

input.id = "email-" +i;
input.name = "email-" +i; 
input.type="email";
input.label ="email-"+i;
input.placeholder="robert.paulson@hotmail.com";

div.innerHTML ='<label for ="email-"'+i+'>'+ "Email # "+i+ " "+'</label>';
div.appendChild(input);
div.appendChild(link_);

mainDiv.appendChild(div);

i++;


}

function removeElement(id){
	while(i>1){
		i--;
if(typeof id ==="object")
	return id.parentNode.removeChild(id);
else
return (elem=document.getElementById(id)).parentNode.removeChild(elem);	
	
	}
}




	



