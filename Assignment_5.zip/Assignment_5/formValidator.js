var formDesign;
var input;

var userNameRegex= /^([A-Za-z][A-Za-z0-9]*){4,12}$/;
var phoneRegex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
var birthdayRegex = /^\d{1,2}\/\d{1,2}\190[0-9]{1,2}|200\d{1}|201[0-6]{1}$/;

var phoneNum;
var userName;
var birthday;
	
window.addEventListener("DOMContentLoaded", function(){
formDesign = document.getElementById('formDesign');
console.log(input = document.getElementsByTagName("input"));
console.log(document.getElementsByTagName("span"));
	// document.getElementsByTagName("span")[0].style.display="inline";
console.log(document.getElementsByTagName("span")[0]);
});

window.onsubmit= function(evt) {


	formDesign.addEventListener("submit", validateForm(evt),false);
}
function validateForm(evt){
     
      
         if( document.signUpForm.user.value == "" || !document.signUpForm.user.value.match(userNameRegex))
         {
            document.signUpForm.user.focus();

	 document.getElementsByTagName("span")[0].style.display="inline";
			evt.preventDefault();
            return false;
         }
         
         if( document.signUpForm.phoneNum.value == "" ||!document.signUpForm.phoneNum.value.match(phoneRegex) )
         {
			document.getElementsByTagName("span")[1].style.display="inline";
            evt.preventDefault();
			document.signUpForm.phoneNum.focus() ;
            return false;
         }
		 
	if( document.signUpForm.birthday.value == ""|| !document.signUpForm.birthday.value.match(birthdayRegex) )
         {
			document.getElementsByTagName("span")[2].style.display="inline";
            evt.preventDefault();
			document.signUpForm.birthday.focus() ;
            return false;
         }
        return( true );
      }	
	
	
